import React from "react";

function Main() {
    return (
        <div>
            <h1>this is Main</h1>
        </div>
    );
}

export default Main;